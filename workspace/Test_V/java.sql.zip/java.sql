-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 24, 2011 at 07:18 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `java`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `names`
-- 

CREATE TABLE `names` (
  `id` int(2) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `names`
-- 

INSERT INTO `names` VALUES (1, 'Ahmed');
INSERT INTO `names` VALUES (2, 'Ali');
